package com.example.cheermeup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {



    TextView memes;
    TextView lolvids;
    TextView fqs;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        memes=findViewById(R.id.memes);
        lolvids=findViewById(R.id.lolvid);
        fqs=findViewById(R.id.fq);

        memes.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view){
             Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.memedroid.com/"));
             startActivity(browserIntent);
         }
        });
        lolvids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.hahaha.com/en/funny-videos"));
            }
        });
        fqs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://tinybuddha.com/"));
            }
        });





    }
}